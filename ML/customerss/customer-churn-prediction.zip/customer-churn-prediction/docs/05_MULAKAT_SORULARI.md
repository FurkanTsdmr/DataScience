# Mülakat Soruları — Bu Projeye Özel Cevaplarla

**S1. Projeyi 1 dakikada anlat.**
"Abonelik şirketi için churn tahmini. 1.820 ham kayıttan 1.800 müşterilik temiz veri çıkardım (8,2% churn). Veri denetiminde ücret–plan çelişkileri ve çakışan ID'ler buldum. Sızıntısız bir sklearn Pipeline kurdum; modelleri tekrarlı CV'de PR-AUC ile karşılaştırdım ve sade Lojistik Regresyon'u seçtim. Eşiği iş değerine göre seçtim, test'te ROC-AUC 0,71 aldım ve belirsizliği bootstrap ile raporladım. Model FastAPI ve Streamlit ile servis ediliyor."

**S2. Neden Accuracy kullanmadın?** Herkese "kalır" diyen model %91,7 Accuracy alır, Recall = 0. PR-AUC, Recall/Precision ve net değer kullandım.

**S3. Data leakage nedir, nerede önledin?** Test bilgisinin eğitime sızması. Medyan/ölçek/kodlama Pipeline içinde, yalnızca eğitim fold'undan öğreniliyor; eşik train out-of-fold'da seçildi; özellik taraması train'de yapıldı.

**S4. `errors="coerce"` neden dikkat gerektirir?** Çevrilemeyeni `NaN` yapar ama bilgi kaybettirebilir. `399TL`'yi "kurtarmak" yanlıştı (doğrusu 479,2): kural kontrolü bunu yakaladı.

**S5. Çakışan ID'leri nasıl çözdün?** Hepsini silmek 8 müşteriyi kaybettirirdi. Zaman damgası yok; **ilk kaydı tuttum**, bunu *varsayım* olarak belgeledim ve çelişen kayıtları ayrı dosyaya yazdım. Gerçekte CRM güncelleme zamanı kullanılmalı.

**S6. Eksik değerleri neden hemen doldurmadın?** Doldurma değeri (medyan) test dahil tüm veriden hesaplanırsa leakage olur. Pipeline içinde, eğitimden öğreniliyor.

**S7. Feature engineering skoru artırdı mı?** Hayır. CV'de base/engineered/core aynı bantta (PR-AUC 0,244/0,240/0,267). Eşit performansta en sade seti seçtim.

**S8. Neden Random Forest değil Lojistik Regresyon?** RF'nin PR-AUC'si (0,275) LR'ninkinden (0,267) 1 standart hata içinde; sade, yorumlanabilir ve **iyi kalibre** (Brier 0,069 vs 0,180) modeli seçtim (1-SE kuralı).

**S9. `class_weight="balanced"` neden kullanmadın?** Sıralamayı değiştirmiyor (Spearman 0,997) ama olasılıkları şişiriyor (ort. %41, gerçek %8). Dengesizliği eşikle ele aldım.

**S10. Eşiği nasıl seçtin?** Train out-of-fold tahminlerinde, kampanya net değerini maksimize eden eşik (kayan ortalamayla yumuşatılmış): 0,10. Sonuç maliyete duyarlı: 20 TL'de herkesi aramak neredeyse aynı kadar iyi, 150 TL'de model yetersiz.

**S11. Test sonuçlarına ne kadar güveniyorsun?** Az. Testte 30 ayrılan var; bootstrap %95 aralığı ROC-AUC için 0,62–0,80. CV 0,75, test 0,71: aralık içinde tutarlı.

**S12. ROC-AUC vs PR-AUC?** ROC-AUC sınıf oranından bağımsız sıralama; PR-AUC pozitif sınıfa odaklı ve dengesizde duyarlı. Rastgele PR-AUC = taban oran (0,083).

**S13. Precision vs Recall bu işte?** Recall: kaçırılan müşteri maliyeti; Precision: gereksiz kampanya maliyeti. Net değer ikisini TL'de birleştirir.

**S14. Korelasyon nedensellik mi?** Hayır. "Memnuniyet düşük → ayrılıyor" kampanyanın işe yarayacağını kanıtlamaz; A/B testi gerekir.

**S15. Cramér's V neden, p-değeri yetmez mi?** p-değeri büyük örneklemde küçük farkta bile anlamlı çıkar; V etkinin büyüklüğünü verir.

**S16. Çoklu test düzeltmesi nedir?** 6 test yapınca tesadüfen p<0,05 çıkma olasılığı ~%26. Benjamini-Hochberg yanlış keşif oranını kontrol eder. Örn: plan ham p=0,04 → düzeltilmiş 0,08.

**S17. Model canlıda bozulursa?** Veri/konsept kayması izlenmeli (girdi dağılımları, skor dağılımı, gerçekleşen churn vs tahmin), periyodik yeniden eğitim, A/B testi.

**S18. Pipeline'ı niye `FunctionTransformer` ile başlattın?** Özellik üretimi API'de ayrıca yazılırsa training-serving skew olur. Aynı kod iki yerde çalışır.

**S19. Bu modeli canlıya alır mıydın?** Doğrudan hayır. Gerçek maliyetleri doğrulayıp, küçük bir A/B testiyle (model hedefli vs rastgele) kampanya kazancını ölçerdim; veri sentetik olduğundan zaten bu bir portföy çalışması.

**S20. En çok neyi öğrendin?** "Bunu doğrulayabildiğim bir kuralla çapraz kontrol etmeden düzeltmeye güvenme" (399TL) ve "özellik eklemek her zaman skor artırmaz".

---
### Bilmen gereken kısa tanımlar
`axis=0` (satır boyunca → sütun sonuçları) / `axis=1` (sütun boyunca → satır sonuçları) · `drop_duplicates` birebir kopyayı siler · `OneHotEncoder` kategoriyi 0/1 sütunlara açar · `StandardScaler` z=(x−µ)/σ · `stratify` sınıf oranını korur · `cross_val_predict` her satır için out-of-fold tahmin verir · `joblib` Python nesnesini diske yazar.
