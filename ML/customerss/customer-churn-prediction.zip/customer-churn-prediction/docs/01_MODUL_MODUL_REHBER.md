# Modül Modül Rehber — Ne yaptık, neden yaptık?

Bu rehber, projeyi **sıfırdan kendi başına yazmak** isteyen biri için hazırlandı. Her bölüm: **ne yapıyoruz → hangi kütüphane/modül → neden → sık yapılan hata**.

---
## 0. Genel felsefe (5 kural)
1. **Ham veriye dokunma.** `data/raw` sabit; her şey kopya üzerinde (`df_raw.copy()`).
2. **Veriyi körü körüne temizleme, önce denetle.** (Notebook 02 → 03)
3. **Test kümesi kutsaldır.** Tek seferlik, en sonda açılır.
4. **Öğrenen her şey Pipeline içinde.** (imputer, scaler, encoder) → sızıntı yok.
5. **Her kararı ölç ve belgele.** "Bu özellik işe yaradı mı?" sorusunu CV ile cevapla.

---
## 1. `src/config.py` — tek gerçek kaynağı
**Ne:** Yollar, iş kuralları (yaş 18–100 …), plan fiyatları, kategori sözlüğü, iş varsayımları.
**Neden:** Aynı kural 5 yerde kopyalanırsa biri unutulur. Kural değişince tek dosya değişir.
**Hata:** Sabitleri notebook hücrelerine gömmek.

## 2. Notebook 01 — İş problemi
**Ne:** Problemi, metrikleri, maliyet varsayımlarını yaz. **Neden:** Yanlış soruya verilen mükemmel cevap işe yaramaz. Başabaş precision: `maliyet / (başarı oranı × müşteri değeri)` → model bunu aşan bir kesim bulabilmeli.
**Hata:** Accuracy'yi ana metrik seçmek (herkese "kalır" demek %91,7 Accuracy verir).

## 3. Notebook 02 + `pandas` — Veriyi anlama
| Fonksiyon | Ne yapar | Neden |
|---|---|---|
| `pd.read_csv(..., dtype={"monthly_fee_tl":"object"})` | CSV okur; ücreti metin bırakır | Bozuk değerleri görebilmek için |
| `.shape`, `.info()`, `.describe()` | Boyut, tip, istatistik | min/max kırmızı bayrakları (yaş −3, 130) |
| `.isna().sum()` | Eksik sayısı | Ama `"free"` gibi **metin eksikler** NaN değildir! |
| `.duplicated()` / `subset="customer_id"` | Tam tekrar / ID çakışması | İki ayrı problem |
| `value_counts(dropna=False)` | Kategori değerleri | `Basic` vs `basic` |
| `crosstab`, `pd.cut` | Çapraz tablo, aralıklama | Alanlar arası tutarlılık (plan ↔ ücret) |

**Büyük ders:** Tek tek sütunlara değil, **sütunlar arası ilişkilere** de bak. Ücret = plan fiyatı × (1 − indirim) kuralı, hem eksikleri kesin geri kazandırdı hem de 5 hatalı plan etiketini ve yanlış `399TL`'yi yakaladı.

## 4. Notebook 03 + `src/data_cleaning.py` — Temizleme
| Adım | Kod fikri | Neden |
|---|---|---|
| Kopya | `df = raw.copy()` | Ham veri korunur |
| Tip | `pd.to_numeric(errors="coerce")` | Çevrilemeyeni `NaN` yapar (hata vermez) — ama bilgi kaybedebilir, önce bak |
| Kategori | `strip` → `lower` → sözlük `map` | Tutarlı kategoriler; bilinmeyen değer **loglanır** |
| Aralık | `.where(between(lo, hi))` | İmkânsız değer → `NaN` (satırı silme: diğer 14 doğru bilgiyi de atarsın) |
| Tutarlılık | ücret/(1−indirim) tam liste fiyatıysa ve plan çelişiyorsa → plan ücretten | Rastgele ücretin başka planın fiyatına kuruşuna denk gelmesi neredeyse imkânsız |
| Tekrar | `drop_duplicates` | Birebir kopya |
| Çakışan ID | **ilk kaydı tut + denetim dosyası** | Hepsini silmek 8 müşteri kaybettirir (1.792); bu bir **varsayımdır** |
| Eksikler | **Doldurma** | **Burada değil** — Pipeline'da (leakage) |
| Log | `reports/cleaning_log.csv` | "Veriye ne yaptın?" sorusunun kanıtı |

**Doğrulama:** Referans dosya ile hücre hücre karşılaştırma; kalan fark 15 hücre (%0,056). Gerçek hayatta referans olmaz → denetim kuralları ve log daha da önemlidir.
**Hata:** `0`/medyan ile her şeyi hemen doldurmak; `coerce` sonrası NaN'leri fark etmemek.

## 5. Notebook 04 — EDA (`matplotlib`, `seaborn`)
| Grafik | Ne gösterir | Dikkat |
|---|---|---|
| `countplot` | Hedef dağılımı (%8) | Dengesizlik → Accuracy yanıltır |
| `hist` | Dağılım şekli | Ücret ayrık tepeli (3 plan) |
| `boxplot` (churn'e göre) | Gruplar arası fark | Aykırı ≠ hata |
| Segment çubukları + **Wilson GA** | Churn oranı + belirsizlik | n küçükse oran güvenilmez |
| Çapraz kontrol (bölge × sözleşme) | **Karıştırıcı** var mı | Bölge etkisi sözleşmeden mi? |
| `heatmap(corr)` | Doğrusal ilişki | Hepsi zayıf (|r|≤0,14); korelasyon ≠ nedensellik |

## 6. Notebook 05 + `scipy`, `statsmodels` — İstatistik
| Soru | Test | Not |
|---|---|---|
| Oran ne kadar kesin? | `proportion_confint(method="wilson")` | Küçük oranlarda normal yaklaşımdan iyi |
| Kategori ↔ churn | `chi2_contingency` + **Cramér's V** | p-değeri gücü söylemez; V söyler |
| Sayısal iki grup | `mannwhitneyu` + rank-biserial r | Normallik varsayımı yok |
| Çok test | `multipletests(method="fdr_bh")` | 6 testte tesadüfen anlamlı çıkma riski ~%26 |
| Eksiklik bilgi taşıyor mu | `fisher_exact` | Küçük örneklem |
| Diğerleri sabitken etki | `sm.Logit` → **odds ratio** | `drop_first` referansı = alfabetik ilk kategori (Annual, Basic) |
| Eğitim-yalnız tarama | aynı testler train'de | Özellik seçimi test'e bakmadan |

## 7. Notebook 06 + `src/features.py` — Feature engineering
Üretilenler: `tenure_group`, `has_late_payment`, `has_support_contact`, `has_complaint`, `total_issues_6m`.
**Kural:** Eksik girdi → eksik özellik (0 değil). **Fonksiyon olarak** yazıldı ve Pipeline'ın ilk adımı oldu (`FunctionTransformer`) → API'de aynı kod.
**Sonuç:** CV'de katkı yok → sade `core` set. **Mülakat cevabı:** "Ürettim, ölçtüm, işe yaramayanı koymadım."
**Hata:** Özelliği ölçmeden "daha çok = daha iyi" sanmak; `monthly_fee_tl`'yi eklemek (tam türev, çoklu doğrusallık).

## 8. Notebook 07 + `src/preprocessing.py`, `src/modeling.py` — Pipeline & modeller
| Parça | Sınıf | Neden |
|---|---|---|
| Bölme | `train_test_split(stratify=y, random_state=42)` | Oran korunur, tekrarlanabilir |
| Eksik | `SimpleImputer(median / most_frequent)` | Eğitimden öğrenir; uç değerlere dayanıklı |
| Ölçek | `StandardScaler` | Lojistik regresyon için; ağaçlar için gereksiz |
| Kodlama | `OneHotEncoder(handle_unknown="ignore")` | Görülmemiş kategori hata vermesin |
| Birleştir | `ColumnTransformer` + `Pipeline` | **Sızıntıyı önler** |
| Baseline | `DummyClassifier` | Referans: Accuracy 0,92, Recall 0 |
| CV | `RepeatedStratifiedKFold(5×3)` | Az pozitifte (118) tek bölme güvenilmez |
| Ayar | `GridSearchCV(scoring="average_precision")` | PR-AUC dengesizde en bilgilendirici |
| Seçim | **1-SE kuralı** | "En yüksek sayı"yı değil, **eşdeğer modeller arasından en sadeyi** seç |
| Kalibrasyon | Brier, `calibration_curve` | `balanced` olasılıkları şişirir (%41 vs %8) |

## 9. Notebook 08 + `src/evaluation.py` — Değerlendirme
* **Confusion matrix:** TN/FP/FN/TP'nin **iş anlamı** (FP = gereksiz arama, FN = kaçan müşteri).
* **Precision** = riskli dediklerimizin gerçekten ayrılan oranı; **Recall** = ayrılanların yakalanan oranı; **F2** Recall'a 2× ağırlık.
* **ROC-AUC** sıralama gücü; **PR-AUC** dengesizde daha duyarlı; **Brier** olasılık doğruluğu.
* **Eşik:** train **out-of-fold** tahminlerinde, **net değer** eğrisiyle seçilir (test'e bakmadan).
* **Duyarlılık analizi:** Sonuç maliyet varsayımına bağlı (20 TL'de değerli, 150 TL'de değil).
* **Bootstrap GA:** 30 ayrılanlık test oynaktır; tek sayıya güvenme.
* **Gain/Lift:** "İlk %10'u ararsak ayrılanların kaçını yakalarız?"
* **Önem:** katsayılar + **CV'li** permütasyon önemi (30 pozitifli testte çok gürültülü).
* **Hata analizi:** kaçırılan 12 ayrılanın profili (hipotez, kanıt değil).

## 10. Kaydetme / API / Streamlit
* `joblib.dump(pipeline)` → **tüm dönüşümler dahil** tek dosya. Sürüm uyumu: aynı scikit-learn gerekir (`model_metadata.json` sürümleri tutar).
* `src/prediction.py`: tek doğrulama + tahmin çekirdeği; API ve Streamlit **aynı fonksiyonu** çağırır.
* `api.py`: Pydantic `Field(ge=, le=)` + `Literal` ile girdi doğrulama (hatalı girdi → **422**).
* `app.py`: Streamlit; `AppTest` ile otomatik test edildi.

## 11. SQL (Notebook 09)
`GROUP BY`, `HAVING`, `CASE WHEN`, **CTE**, `RANK()`, `ROW_NUMBER()`, `NTILE()`, `SUM() OVER (ORDER BY …)`. Model skorları **dürüst** (OOF/hold-out) olduğundan "risk kademesi başarımı" sorgusu gerçekçidir.

## 12. Testler (`tests/`, 45 test)
Temizleme sayıları ve referansla uyum, özellik kenar durumları (tenure sınırları, eksik semantiği), tüm özellik setlerinde Pipeline, **kimlik/hedef/ücret model girdisinde yok** testi, API doğrulaması, Streamlit çalıştırma, SQL toplam tutarlılığı.
**Neden:** "Sıfır hata" iddiası el ile değil testle kanıtlanır.
