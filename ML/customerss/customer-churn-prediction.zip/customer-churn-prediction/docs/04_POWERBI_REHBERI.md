# Power BI Dashboard Rehberi

> **Dürüst not:** Power BI masaüstü uygulaması olduğu için `.pbix` dosyasını ben üretemem. Aşağıda **hazır veri dosyaları, ölçüler (DAX) ve sayfa düzeni** var; 30–45 dakikada kendin kurabilirsin. (Rakamlar bu projedeki gerçek çıktılarla doğrulanabilir.)

## 1. Yüklenecek dosyalar
| Dosya | İçerik |
|---|---|
| `data/processed/scored_customers.csv` | 1.800 müşteri + `risk_score`, `risk_tier`, `flagged`, `score_source` (**dürüst skorlar**: eğitim için out-of-fold, test için hold-out) |
| `reports/model_comparison.csv` | Model karşılaştırması |
| `reports/threshold_table_train_oof.csv` | Eşik tablosu |
| `reports/cost_sensitivity.csv` | Maliyet duyarlılığı |

**Get Data → Text/CSV** ile yükle. `scored_customers` için sütun tiplerini kontrol et: `risk_score` Decimal, `churn`/`flagged` Whole number.

## 2. Ölçüler (DAX)
```DAX
Toplam Müşteri = COUNTROWS(scored_customers)
Ayrılan = SUM(scored_customers[churn])
Churn Oranı = DIVIDE([Ayrılan], [Toplam Müşteri])
Elde Tutma Oranı = 1 - [Churn Oranı]
Yüksek Riskli Müşteri = CALCULATE([Toplam Müşteri], scored_customers[risk_tier] = "High")
Yüksek Risk Payı = DIVIDE([Yüksek Riskli Müşteri], [Toplam Müşteri])
Yüksek Kademede Gerçek Churn = CALCULATE([Churn Oranı], scored_customers[risk_tier] = "High")
Yakalanan Ayrılan Payı = DIVIDE(CALCULATE([Ayrılan], scored_customers[flagged] = 1), [Ayrılan])
Riskteki Aylık Gelir = CALCULATE(SUM(scored_customers[monthly_fee_tl]), scored_customers[flagged] = 1)
Riskteki Gelir Payı = DIVIDE([Riskteki Aylık Gelir], SUM(scored_customers[monthly_fee_tl]))
Lift = DIVIDE([Yüksek Kademede Gerçek Churn], [Churn Oranı])
```
Beklenen değerler (doğrulama için): Toplam **1.800**, Churn **%8,22**, High **508** müşteri (**%28,2**), High kademede gerçek churn **%17,3**, yakalanan ayrılan payı ≈ **%59,5**.

## 3. Sayfa 1 — Executive Summary
* **Kartlar:** Toplam Müşteri, Churn Oranı, Yüksek Riskli Müşteri, Riskteki Gelir Payı.
* **Sütun grafiği:** `contract_type` × Churn Oranı (+ ayrı sayfada güven aralığı yok; küçük n uyarısı için ipucu ekle).
* **Sütun:** `tenure_group` (Power Query'de `tenure_months` için koşullu sütun) × Churn Oranı.
* **Çubuk:** `region` × Churn Oranı. *Not:* bölge farkı çoklu test düzeltmesinden sonra anlamlı değil → başlığa "(fark istatistiksel olarak belirsiz)" yaz.
* **Dilimleyiciler:** plan, contract_type, risk_tier.

## 4. Sayfa 2 — Model & Risk
* **Risk kademesi:** `risk_tier` × Müşteri sayısı ve Gerçek Churn (High %17,3 > Medium %8,1 > Low %2,7: **tek yönlü ayrışma** model işe yarıyor demektir).
* **Tablo (riskli müşteri listesi):** `customer_id, contract_type, tenure_months, satisfaction_score, risk_score` → `risk_score` azalan, `flagged = 1` filtresi.
* **Dağılım:** `satisfaction_score` × churn (boxplot yerine sütun histogramı).
* **Eşik grafiği:** `threshold_table_train_oof` → X: threshold; Y: precision, recall (çizgi). Net değer için ikinci eksen.

## 5. Sayfa 3 — Varsayımlar ve Sınırlılıklar
Metin kutuları: *"Veri sentetiktir. Net değer, varsayımsal maliyetlere dayanır (kampanya 50 TL, başarı %30, marj %40, 12 ay). Test'te 30 ayrılan var; metrikler geniş belirsizlik taşır. Kampanya etkisi A/B testiyle doğrulanmalı."* + `cost_sensitivity` tablosu.

## 6. Kalite kontrol listesi
- [ ] Kartlardaki rakamlar yukarıdaki beklenen değerlerle aynı mı?
- [ ] `risk_tier` sıralaması High → Medium → Low mu (Sort by column)?
- [ ] Her grafikte n (müşteri sayısı) görünüyor mu?
- [ ] Skorların "out-of-fold / hold-out" olduğu bir alt notta yazıyor mu?
